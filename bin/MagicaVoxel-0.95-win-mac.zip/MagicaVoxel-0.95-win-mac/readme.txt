[MagicaVoxel : 8-bit Voxel Editor]
================================
date    : 02/05/2015

version : 0.95

os      : Win32, MacOS

website : https://voxel.codeplex.com/

twitter : @ ephtracy

